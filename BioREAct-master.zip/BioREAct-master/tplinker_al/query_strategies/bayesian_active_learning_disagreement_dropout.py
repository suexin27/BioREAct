import numpy as np
import torch
from .strategy import Strategy

class BALDDropout(Strategy):
    def __init__(self, dataset, n_drop=10):
        super(BALDDropout, self).__init__(dataset)
        self.n_drop = n_drop

    def query(self, n):
        unlabeled_idxs, unlabeled_data = self.dataset.get_unlabeled_data()
        probs1,probs2,probs3 = self.predict_prob_dropout_split(unlabeled_data, n_drop=self.n_drop)
        pb1 = probs1.mean(0)
        pb2 = probs2.mean(0)
        pb3 = probs3.mean(0)
        entropy1_1 = (-pb1*torch.log(pb1)).sum(2)
        entropy1_2= (-pb2 * torch.log(pb2)).sum(3)
        entropy1_3 = (-pb2 * torch.log(pb2)).sum(3)
        entropy2_1 = (-probs1*torch.log(probs1)).sum(3).mean(0)
        entropy2_2 = (-probs2 * torch.log(probs2)).sum(4).mean(0)
        entropy2_3 = (-probs3 * torch.log(probs3)).sum(4).mean(0)
        uncertainties1 = (entropy2_1 - entropy1_1).sum(1)
        uncertainties2 = (entropy2_2 - entropy1_2).sum(2).max(1)[0]
        uncertainties3 = (entropy2_3 - entropy1_3).sum(2).max(1)[0]
        uncertainties = (uncertainties1 + uncertainties2 + uncertainties3) * 1 / 3
        return unlabeled_idxs[uncertainties.sort()[1][:n]]
