import numpy as np
from .strategy import Strategy

class LeastConfidenceDropout(Strategy):
    def __init__(self, dataset, n_drop=10):
        super(LeastConfidenceDropout, self).__init__(dataset)
        self.n_drop = n_drop

    def query(self, n):
        unlabeled_idxs, unlabeled_data = self.dataset.get_unlabeled_data()
        # probs = self.predict_prob_dropout(unlabeled_data, n_drop=self.n_drop)
        probs1, probs2, probs3 = self.predict_prob_dropout(unlabeled_data,n_drop=self.n_drop)
        ent1 = probs1.max(2)[0]  # (,5050)
        ent = ent1.log().sum(dim=1, keepdim=True)  # (,1)
        head1 = probs2.max(3)[0]  # (,4,5050)
        head2 = head1.log().sum(dim=2, keepdim=True)  # (,4)
        head3 = head2.max(1)[0]  # (6,1)
        tail1 = probs3.max(3)[0]
        tail2 = tail1.log().sum(dim=2, keepdim=True)
        tail3 = tail2.max(1)[0]
        rel = (head3 + tail3) * 1 / 2
        uncertainties = (ent + rel) * 1/2
        return unlabeled_idxs[uncertainties.sort()[1][:n]]
